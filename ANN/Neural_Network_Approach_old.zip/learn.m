
% Feedforward Neural Network with Backpropagation
% Author : Sreenatha Bhatlapenumarthi


% Initialization
epsolon = 1;
theta1 = rand(5,13) * epsolon;
theta2 = rand(27,5) * epsolon;
delta3 = zeros(1,5);
delta3 = zeros(1,27); 
Delta1 = zeros(5,13);
Delta2 = zeros(27,5);

% Extract training data
train_input = [];
train_output = [];
train_dir = dir('./train_data');
classes = length(train_dir)-2;
for class_it=3:length(train_dir)
    class = train_dir(class_it).name;
    class_dir = dir(fullfile('./train_data', class));
    for sample_it=3:length(class_dir)
        [sample freq] = wavread(fullfile('./train_data',class,class_dir(sample_it).name));
        sample_mfcc = mfcc(sample, freq, 0.25);
        train_input = [train_input; sample_mfcc'];
        output = zeros(1,classes);
        output(str2num(class)) = 1;
        train_output = [train_output; output];
    end;
end;


% Apply learning algorithm
for i=1:size(train_input,1)
    a2 = sigmoid(train_input(i,:) * theta1');
    output = sigmoid(a2 * theta2');    
    %Calculate Cost Function
    %cost = 0;
    %for k=1:27
    %    cost = cost + log(output(k));  % first cost term
    %    cost = cost + ((1-train_output(i,k)) * log(1 - output(k))); % second cost term
    %end;
    delta3 = output - train_output(i,:);    
    %delta2 = (delta3 * theta2) .* (a2 .* (1-a2));
    delta2 = (delta3 * theta2) .* sigmoid(a2);     
    %delta2' * train_input(i,:)
    Delta1 = Delta1 + (delta2' * train_input(i,:));
    Delta1
    Delta2 = Delta2 + (delta3' * a2);
end;


